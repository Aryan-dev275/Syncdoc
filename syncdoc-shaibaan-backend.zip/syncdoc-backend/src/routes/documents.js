const express = require("express");
const store = require("../store");
const sanitizeDocument = require("../middleware/sanitize");
const { readBlocks, blocksToHTML } = require("../services/blocks");
const { createHTMLDocument } = require("../services/htmlExport");

const router = express.Router();
const cleanTitle = (t) => String(t ?? "").replace(/[<>]/g, "").trim();

router.param("id", (req, res, next, id) => {
  if (!store.safeId(id)) return res.status(400).json({ error: "Invalid document id" });
  next();
});

router.get("/", (req, res) => res.json(store.listDocuments()));

router.post("/", (req, res) => {
  const id = req.body?.id || `doc-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  if (!store.safeId(id)) return res.status(400).json({ error: "Invalid document id" });
  if (store.hasDocument(id)) return res.status(409).json({ error: "Document already exists" });
  res.status(201).json(store.createDocument(id, cleanTitle(req.body?.title) || "Untitled"));
});

router.get("/:id", (req, res) => {
  if (!store.hasDocument(req.params.id)) return res.status(404).json({ error: "Not found" });
  const blocks = readBlocks(store.getYDoc(req.params.id));
  res.json({ ...store.getMeta(req.params.id), blocks });
});

router.patch("/:id", sanitizeDocument, (req, res) => {
  const title = cleanTitle(req.body?.title);
  if (!title) return res.status(400).json({ error: "title required" });
  const updated = store.renameDocument(req.params.id, title);
  if (!updated) return res.status(404).json({ error: "Not found" });
  res.json(updated);
});

router.delete("/:id", (req, res) => {
  if (!store.deleteDocument(req.params.id)) return res.status(404).json({ error: "Not found" });
  res.status(204).end();
});

// Export: GET /api/documents/:id/export?format=html|json|md
router.get("/:id/export", (req, res) => {
  const { id } = req.params;
  if (!store.hasDocument(id)) return res.status(404).json({ error: "Not found" });
  const { title } = store.getMeta(id);
  const blocks = readBlocks(store.getYDoc(id));
  const format = String(req.query.format || "html").toLowerCase();
  const file = title.replace(/[^\w-]+/g, "_") || id;

  if (format === "html") {
    res.type("html").attachment(`${file}.html`);
    return res.send(createHTMLDocument(blocksToHTML(blocks), title));
  }
  if (format === "json") {
    res.attachment(`${file}.json`);
    return res.json({ id, title, blocks });
  }
  if (format === "md") {
    const md = blocks.map((b) =>
      b.type === "heading" ? `# ${b.content}` : b.type === "code" ? "```" + (b.language || "") + `\n${b.content}\n` + "```" : b.content
    ).join("\n\n");
    res.type("text/markdown").attachment(`${file}.md`);
    return res.send(`# ${title}\n\n${md}\n`);
  }
  res.status(400).json({ error: "format must be html, json or md" });
});

module.exports = router;
