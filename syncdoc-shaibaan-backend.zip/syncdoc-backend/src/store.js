const fs = require("fs");
const path = require("path");
const Y = require("yjs");

const DATA_DIR = path.resolve(process.env.DATA_DIR || "./data");
const META_FILE = path.join(DATA_DIR, "documents.json");
fs.mkdirSync(DATA_DIR, { recursive: true });

// id -> { id, title, createdAt, updatedAt }
let meta = {};
try { meta = JSON.parse(fs.readFileSync(META_FILE, "utf8")); } catch { /* first run */ }

const ydocs = new Map();   // id -> Y.Doc (loaded)
const timers = new Map();  // id -> debounce timer

const safeId = (id) => /^[\w-]{1,64}$/.test(id);
const binPath = (id) => path.join(DATA_DIR, `${id}.bin`);
const saveMeta = () => fs.writeFileSync(META_FILE, JSON.stringify(meta, null, 2));

function saveDoc(id) {
  const ydoc = ydocs.get(id);
  if (!ydoc) return;
  fs.writeFileSync(binPath(id), Y.encodeStateAsUpdate(ydoc));
  if (meta[id]) { meta[id].updatedAt = new Date().toISOString(); saveMeta(); }
}

function scheduleSave(id) {
  clearTimeout(timers.get(id));
  timers.set(id, setTimeout(() => { timers.delete(id); saveDoc(id); }, 1000));
}

function createDocument(id, title = "Untitled") {
  if (!safeId(id)) throw new Error("Invalid document id");
  if (!meta[id]) {
    const now = new Date().toISOString();
    meta[id] = { id, title: String(title).slice(0, 200), createdAt: now, updatedAt: now };
    saveMeta();
  }
  return meta[id];
}

/** Get (or load from disk / create) the Yjs doc for an id. */
function getYDoc(id) {
  if (!safeId(id)) throw new Error("Invalid document id");
  if (ydocs.has(id)) return ydocs.get(id);
  const ydoc = new Y.Doc();
  try { Y.applyUpdate(ydoc, fs.readFileSync(binPath(id))); } catch { /* new doc */ }
  createDocument(id);
  ydoc.on("update", () => scheduleSave(id));
  ydocs.set(id, ydoc);
  return ydoc;
}

const listDocuments = () => Object.values(meta).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
const getMeta = (id) => meta[id];
const hasDocument = (id) => Boolean(meta[id]);

function renameDocument(id, title) {
  if (!meta[id]) return null;
  meta[id].title = String(title).slice(0, 200);
  meta[id].updatedAt = new Date().toISOString();
  saveMeta();
  return meta[id];
}

function deleteDocument(id) {
  if (!meta[id]) return false;
  clearTimeout(timers.get(id)); timers.delete(id);
  ydocs.get(id)?.destroy(); ydocs.delete(id);
  delete meta[id]; saveMeta();
  fs.rmSync(binPath(id), { force: true });
  return true;
}

function flushAll() { for (const id of ydocs.keys()) saveDoc(id); }

module.exports = { safeId, createDocument, getYDoc, listDocuments, getMeta, hasDocument, renameDocument, deleteDocument, flushAll };
